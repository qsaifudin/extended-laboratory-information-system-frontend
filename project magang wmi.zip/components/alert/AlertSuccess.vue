<template>
  <div>
    <v-alert type="success"> Data berhasil ditambahkan </v-alert>
  </div>
</template>
