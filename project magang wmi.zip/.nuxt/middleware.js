const middleware = {}

middleware['isAdmin'] = require('..\\middleware\\isAdmin.js')
middleware['isAdmin'] = middleware['isAdmin'].default || middleware['isAdmin']

middleware['isSuperadmin'] = require('..\\middleware\\isSuperadmin.js')
middleware['isSuperadmin'] = middleware['isSuperadmin'].default || middleware['isSuperadmin']

export default middleware
