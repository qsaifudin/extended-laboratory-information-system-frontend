export default {"theme":{"themes":{"light":{"primary":"#00BFA5","secondary":"#E2C790","softgrey":"#f5f5f5","softgreen":"#ECFAF8","success":"#00BFA5"}}}}
