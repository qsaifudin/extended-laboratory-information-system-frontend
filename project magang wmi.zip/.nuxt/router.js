import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _155605cd = () => interopDefault(import('..\\pages\\kategoriRs\\index.vue' /* webpackChunkName: "pages/kategoriRs/index" */))
const _f677171a = () => interopDefault(import('..\\pages\\lab\\index.vue' /* webpackChunkName: "pages/lab/index" */))
const _af5e7aea = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _42aac3da = () => interopDefault(import('..\\pages\\rs\\index.vue' /* webpackChunkName: "pages/rs/index" */))
const _49eb0c68 = () => interopDefault(import('..\\pages\\transaksiPasien\\index.vue' /* webpackChunkName: "pages/transaksiPasien/index" */))
const _0340ebc9 = () => interopDefault(import('..\\pages\\user\\index.vue' /* webpackChunkName: "pages/user/index" */))
const _684c17ac = () => interopDefault(import('..\\pages\\vendor\\index.vue' /* webpackChunkName: "pages/vendor/index" */))
const _4b15074d = () => interopDefault(import('..\\pages\\kategoriRs\\kategoriRsDetail.vue' /* webpackChunkName: "pages/kategoriRs/kategoriRsDetail" */))
const _b0c7dd42 = () => interopDefault(import('..\\pages\\lab\\labDetail.vue' /* webpackChunkName: "pages/lab/labDetail" */))
const _28bcc868 = () => interopDefault(import('..\\pages\\rs\\rumkitDetail.vue' /* webpackChunkName: "pages/rs/rumkitDetail" */))
const _94bc00a2 = () => interopDefault(import('..\\pages\\transaksiPasien\\transaksiDetail.vue' /* webpackChunkName: "pages/transaksiPasien/transaksiDetail" */))
const _e87d8ad6 = () => interopDefault(import('..\\pages\\user\\userDetail.vue' /* webpackChunkName: "pages/user/userDetail" */))
const _3cd96642 = () => interopDefault(import('..\\pages\\user\\userPassword.vue' /* webpackChunkName: "pages/user/userPassword" */))
const _47e3be4f = () => interopDefault(import('..\\pages\\vendor\\vendorDetail.vue' /* webpackChunkName: "pages/vendor/vendorDetail" */))
const _42adc118 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/kategoriRs",
    component: _155605cd,
    name: "kategoriRs"
  }, {
    path: "/lab",
    component: _f677171a,
    name: "lab"
  }, {
    path: "/login",
    component: _af5e7aea,
    name: "login"
  }, {
    path: "/rs",
    component: _42aac3da,
    name: "rs"
  }, {
    path: "/transaksiPasien",
    component: _49eb0c68,
    name: "transaksiPasien"
  }, {
    path: "/user",
    component: _0340ebc9,
    name: "user"
  }, {
    path: "/vendor",
    component: _684c17ac,
    name: "vendor"
  }, {
    path: "/kategoriRs/kategoriRsDetail",
    component: _4b15074d,
    name: "kategoriRs-kategoriRsDetail"
  }, {
    path: "/lab/labDetail",
    component: _b0c7dd42,
    name: "lab-labDetail"
  }, {
    path: "/rs/rumkitDetail",
    component: _28bcc868,
    name: "rs-rumkitDetail"
  }, {
    path: "/transaksiPasien/transaksiDetail",
    component: _94bc00a2,
    name: "transaksiPasien-transaksiDetail"
  }, {
    path: "/user/userDetail",
    component: _e87d8ad6,
    name: "user-userDetail"
  }, {
    path: "/user/userPassword",
    component: _3cd96642,
    name: "user-userPassword"
  }, {
    path: "/vendor/vendorDetail",
    component: _47e3be4f,
    name: "vendor-vendorDetail"
  }, {
    path: "/",
    component: _42adc118,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
