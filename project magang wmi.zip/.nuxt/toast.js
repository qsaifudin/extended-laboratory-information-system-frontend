import { createToastInterface } from "vue-toastification";

export default function (ctx, inject) {
  const toast = createToastInterface({"cssFile":"D:\\doc\\lOCALHOST\\PROJECT\\PROJEKAN\\MAGANG\\extended_system_lis_frontend\\node_modules\\vue-toastification\\dist\\index.css","timeout":1000,"closeOnClick":false,"position":"top-center"});
  inject('toast', toast);
}
