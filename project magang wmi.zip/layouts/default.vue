<template>
  <v-app> <sidebar /> </v-app>
</template>

<script>
import Sidebar from '~/components/Sidebar'
export default {
  components: {
    Sidebar,
  },
}
</script>

<style></style>
