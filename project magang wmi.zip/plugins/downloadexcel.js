import Vue from 'vue'
import JsonExcel from 'vue-json-excel'

Vue.component('Downloadexcel', JsonExcel)
